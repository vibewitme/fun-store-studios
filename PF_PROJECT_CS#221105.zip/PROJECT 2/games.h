// each fuction contains a text file that print/reads the description of the of each game
void printf_chess();
void printf_chess()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("chess.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
	
	                
}
void printf_monopoly();
void printf_monopoly()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Monopoly.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_sequence();
void printf_sequence()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("sequence.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_callofduty();
void printf_callofduty()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Call of Duty.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_counterstrike();
void printf_counterstrike()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Counter strike.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_mortalcombat();
void printf_mortalcombat()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Mortal combat.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_dreamleaguesoccer();
void printf_dreamleaguesoccer()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Dream League Soccer.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_realcricket();
void printf_realcricket()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Real Cricket.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_rocketleague();
void printf_rocketleague()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Rocket League.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_colorsokpuzzle();
void printf_colorsokpuzzle()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Colorsok puzzle.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_cleanuppuzzle();
void printf_cleanuppuzzle()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Cleanup puzzle.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_calculatorpuzzle();
void printf_calculatorpuzzle()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Calculator puzzle.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_minecraft();
void printf_minecraft()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Minecraft.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_destiny2();
void printf_destiny2()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Destiny 2.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
void printf_fornite();
void printf_fornite()
{
	FILE *fptr;
    char ch = 0;
    fptr = fopen("Fornite.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}