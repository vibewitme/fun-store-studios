#include<stdio.h>
#include<stdlib.h>
#include"games.h"
#include"cart.h"


int main()
{   
    printf("\n\t\t\t\t\t\t                      ********************\n");
    printf("\n\t\t\t\t\t\t        =============================================");
    printf("\n\t\t\t\t\t\t        =                 WELCOME                   =");
    printf("\n\t\t\t\t\t\t        =                   TO                      =");
    printf("\n\t\t\t\t\t\t        =                FUN STORE                  =");
    printf("\n\t\t\t\t\t\t        =                 STUDIOS                   =");
    printf("\n\t\t\t\t\t\t        =============================================");
    printf("\n\n\t\t\t\t\t\t                      ********************\n\n\n");
    printf("\n\n\t\t\t\t1. View Games ");
    printf("\n\n\t\t\t\t2. Purchase Games ");
    printf("\n\n\t\t\t\t Choose your Option : ");
    int n;
    scanf("%d",&n);
   int choice;
   char userinput =0;
   // switch case containing two cases (to view the items in the store) and (to purchase the items)
    switch (n)
   {
      // outer switch case 1 to select the category
      case 1:
         //loop to view the categories aslong as the user wants   
         do
         {
            printf("\n\n\t\t\t\tMenu\n\n");
            printf("\t\t\t\t1.Board games.\n");
            printf("\t\t\t\t2.Action-Adventure.\n");
            printf("\t\t\t\t3.Sports.\n");
            printf("\t\t\t\t4.Puzzle.\n");
            printf("\t\t\t\t5.Multiplayer.\n\n\n");
            printf("\t\t\t\tEnter your favourite category: ");
            scanf("%d",&choice);
            int g_number;
            // this switch into switch goes into the desired category and locates/prints the description of a game with the help of function calling 
            switch(choice)    
            {
               case 1: printf("\n\n\n\t\t\t\tBoard games.\n\n\t\t\t\t1. Chess.\n\t\t\t\t2. Monopoly.\n\t\t\t\t3. Sequence. \n\n");
                     printf("\n\t\t\t\tEnter the game number you want to download: ");
                     scanf("%d",&g_number);
                     if(g_number==1)
                        {
                           printf_chess();
                        }
                        else if(g_number==2)
                        {
                           printf_monopoly();
                        }
                        else if(g_number==3)
                        {
                        printf_sequence();
                        }
                        break;
               case 2: printf("\n\n\n\t\t\t\tAction-Adventure.\n\n\t\t\t\t1. Call of Duty.\n\t\t\t\t2. Counter strike 1.6.\n\t\t\t\t3. Mortal Combat.\n\n");
                     printf("\n\t\t\t\tEnter the game number you want to download: ");
                     scanf("%d",&g_number);
                     if(g_number==1)
                        {
                           printf_callofduty();
                        }
                        else if(g_number==2)
                        {
                           printf_counterstrike();
                        }
                        else if(g_number==3)
                        {
                           printf_mortalcombat();
                        }
                        break;
               case 3: printf("\n\n\n\t\t\t\tSports.\n\n\t\t\t\t1. Dream league soccer.\n\t\t\t\t2. Real Cricket.\n\t\t\t\t3. Rocket League.\n\n");
                     printf("\n\t\t\t\tEnter the game number you want to download: ");
                     scanf("%d",&g_number);
                     if(g_number==1)
                        {
                           printf_dreamleaguesoccer();
                        }
                        else if(g_number==2)
                        {
                           printf_realcricket();
                        }
                        else if(g_number==3)
                        {
                           printf_rocketleague();
                        }
                        break;
               case 4: printf("\n\n\n\t\t\t\tPuzzle.\n\n\t\t\t\t1. Colorsok Puzzle.\n\t\t\t\t2. Cleanup Puzzle.\n\t\t\t\t3. Calculator Puzzle.\n\n");
                     printf("\n\t\t\t\tEnter the game number you want to download: ");
                     scanf("%d",&g_number);
                     if(g_number==1)
                        {
                           printf_colorsokpuzzle();
                        }
                        else if(g_number==2)
                        {
                           printf_cleanuppuzzle();
                        }
                        else if(g_number==3)
                        {
                           printf_calculatorpuzzle();
                        }
                        break;
               case 5: printf("\n\n\n\t\t\t\tMultiplayer.\n\n\t\t\t\t1. Minecraft.\n\t\t\t\t2. Destiny2.\n\t\t\t\t3. Fortnite.\n\n");
                     printf("\n\t\t\t\tEnter the game number you want to download: ");
                     scanf("%d",&g_number);
                     if(g_number==1)
                        {
                           printf_minecraft();
                        }
                        else if(g_number==2)
                        {
                           printf_destiny2();
                        }
                        else if(g_number==3)
                        {
                           printf_fornite();
                        }
                        break;
                        default:
                        break;
                                       
            }
               printf("\n\n\t\t\t\tDo you wish to view another category : \n\t\t\t\tpress y/n? ");
               scanf(" %c",&userinput);
               if(userinput == 'n') 
               {
                  choice = 0;
               }
         } while(choice !=0);//scope of do while 
         // the view option also prints the menu at the end if the user wants to purchase any game by calling price fuction in (cart.h) header file
           price();
         // if the user decides to purchase bill fuction is called which is the (cart.h) header file
           bill();
           getchar();
           break;
         //   outer switch to purchase items
            case 2:
                //calling price fuction in (cart.h) header file to print the menu through a text file 
                  price(); 
                  printf("\n\n\t\t\t\tDo you want to add any game to the cart?\n");
                  printf("\n\t\t\t\tIf yes press y and n if no ");
                  char a;
                  int m;
                  // if user wants to purchase this loop will execute
                  do
                  {
                     getchar(); 
                     scanf("%c",&a);
                     if(a=='y'|| a=='Y')
                     {
                           bill();
                     }
                     else if(a=='n'|| a=='N')
                     {
                           printf("\n ");
                           system("cls");
                           break;
                     }
                  } while (a!='n'|| a!='N');         
                        break;
                        default: 
                        break;
   }
                     getchar();
                     system("cls");
                     return 0;
}
