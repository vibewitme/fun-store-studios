// price fuction overall prints the menu with the help of text file
int price();
int price()
{
    FILE *fptr;
    char ch = 0;
    fptr = fopen("price.txt","r");
    while( (ch=getc(fptr)) !=EOF){
        printf("%c",ch);
    }
    return 0;
}
// bill fuction contains the prices of each game which helps to calculate the bill at the end of the program 
void bill();
void bill()
{
    int bill[20000]={550,300,250,1500,350,450,240,390,4500,120,150,180,1200,9500,850};
    int sum=0,m,choice;
    do{
        printf("\n\t\t\t\tEnter the Game Number you want to download :");
        scanf("%d",&m);
        sum+=bill[m-1];
        printf("\n\t\t\t\tDo you want to enter another game?");
        scanf(" %c",&choice);
    }
    while (choice=='y');
    printf("\n\t\t\t\tTOTAL BILL AMOUNT = %d ",sum);
    printf("\n\t\t\t\tHappy Shopping ");

}